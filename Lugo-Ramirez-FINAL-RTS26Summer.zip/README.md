# App 5 scaffold — dual-core IPC pipeline

Scaffold level: **~65%** (the pipeline logic is yours; the observability infrastructure is provided).

## What's wired

- Queue (`data_q`), event group (`evt_group`), task notification target (`responder_handle`)
- Producer / consumer / coordinator / responder task skeletons on Core 1
- Button ISR &rarr; direct task notification path
- Per-task heartbeat counters (`hb_prod` / `hb_cons` / `hb_coord` / `hb_resp`)
- A Core-0 monitor behind one `#define`: a working serial monitor (`USE_WEBSERVER=0`) or the web-monitor stub you complete (`USE_WEBSERVER=1`)

## Run modes (`USE_WEBSERVER`)

`USE_WEBSERVER` picks the Core-0 observability plane; the Core-1 pipeline is identical either way. One line at the top of `main.c`:

```c
#define USE_WEBSERVER 0   /* 0 = serial monitor (provided), 1 = web monitor (you build) */
```

- `USE_WEBSERVER = 0` — **serial monitor, provided and working.** Prints queue depth (`uxQueueMessagesWaiting`), event-group bits, and the four heartbeats once a second. No Wi-Fi, so the pipeline runs in Wokwi out of the box. This is your baseline.
- `USE_WEBSERVER = 1` — **web monitor, your deliverable.** Runs `webmonitor_task` instead, where you port App 1's HTTP server and render the same fields over HTTP.

Start on `0` to get the pipeline moving in the simulator, then flip to `1` once the web monitor is in.

## What you build

1. **Producer body** — themed data items, queue send with a back-pressure policy
2. **Consumer body** — receive with timeout, themed processing (delete the placeholder `vTaskDelay` once your `xQueueReceive` blocks for you)
3. **Web monitor** — port App 1's HTTP code into `webmonitor_task` (the `USE_WEBSERVER=1` path), add live queue depth + event-bit readout
4. **Queue sizing** — pick depth + item size, and defend it
5. **Theme** — names, log messages, the meaning of "a data item"

The coordinator &rarr; responder rendezvous is already wired (just verify it), and the heartbeat counters are already provided and fed into the serial monitor.

## Explain in README

- **Queue depth**: how did you size it? Compute the worst-case burst your producer can deliver before the consumer catches up. Show the math.
- **Back-pressure policy**: queue full means... drop oldest? drop newest? block producer? log + drop? Justify.
- **Event-group vs N semaphores**: explain why the event group is the better fit for the producer-consumer rendezvous.
- **Direct notification vs binary semaphore**: measure wake latency on both paths (you have the App 3 helper). Numbers in your README.

## Where to copy from

- App 1's HTTP server: reuse `wifi_init_sta()`, `handle_root()`, `start_webserver()` patterns - drop them into `webmonitor_task` under `USE_WEBSERVER=1`
- App 3's latency-measurement helper: drop it in for the notification path

Heartbeat counters are already provided (`hb_prod` / `hb_cons` / `hb_coord` / `hb_resp`), so you can skip that copy from App 2 and go straight to reading them in your web page/terminal.

Concurrency diagram:

===============================================================================
          APP 5 — HULK ROLLER COASTER CONCURRENCY DIAGRAM
===============================================================================


                     CORE 1 — REAL-TIME CONTROL PIPELINE
-------------------------------------------------------------------------------

+-----------------------------+
| producer_task               |
| Hulk Button Input           |
| Priority 8                  |
|-----------------------------|
| Creates RideItem_t command  |
| Runs every 500 ms           |
| Increments hb_prod          |
+--------------+--------------+
               |
               | xQueueSend()
               | Typed FIFO: RideItem_t
               v
+-----------------------------+
| Queue: data_q               |
|-----------------------------|
| Depth: 8 items              |
| Preserves command order     |
| Provides back pressure      |
+--------------+--------------+
               |
               | xQueueReceive()
               v
+-----------------------------+
| consumer_task               |
| Hulk State Machine          |
| Priority 8                  |
|-----------------------------|
| Processes ride command      |
| Updates coaster state       |
| Increments hb_cons          |
+--------------+--------------+
               |
               | Sets:
               | EV_BIT_DATA_PROCESSED
               v


 producer_task                         consumer_task
       |                                     |
       | EV_BIT_DATA_PRODUCED                | EV_BIT_DATA_PROCESSED
       |                                     |
       +------------------+------------------+
                          |
                          v
              +-----------------------------+
              | Event Group: evt_group      |
              |-----------------------------|
              | Bit 0: Data produced        |
              | Bit 1: Data processed       |
              +--------------+--------------+
                             |
                             | Wait for ALL bits
                             | xEventGroupWaitBits()
                             v
              +-----------------------------+
              | coordinator_task            |
              | Pipeline Coordinator        |
              | Priority 9                  |
              |-----------------------------|
              | Confirms cycle completed    |
              | Clears event bits           |
              | Increments hb_coord         |
              +--------------+--------------+
                             |
                             | xTaskNotifyGive()
                             | Direct task notification
                             v
              +-----------------------------+
              | responder_task              |
              | Hulk Operator Display       |
              | Priority 12                 |
              |-----------------------------|
              | Displays current ride state |
              | Increments hb_resp          |
              +-----------------------------+


                     BUTTON INTERRUPT PATH
-------------------------------------------------------------------------------

+-----------------------------+
| GPIO 18 Button              |
| Operator / emergency input  |
+--------------+--------------+
               |
               | Falling-edge interrupt
               v
+-----------------------------+
| button_isr()                |
|-----------------------------|
| Debounces button            |
| Records ISR timestamp       |
| Wakes responder directly    |
+--------------+--------------+
               |
               | vTaskNotifyGiveFromISR()
               | portYIELD_FROM_ISR()
               v
+-----------------------------+
| responder_task              |
| Hulk Operator Display       |
|-----------------------------|
| Measures wakeup latency     |
| Performs themed response    |
+-----------------------------+


                 CORE 0 — OBSERVABILITY PLANE
-------------------------------------------------------------------------------

+-----------------------------+
| serial_monitor_task         |
| or webmonitor_task          |
| Priority 4                  |
|-----------------------------|
| Reads queue depth           |
| Reads event-group bits      |
| Reads task heartbeats       |
| Reports current ride state  |
+--------------+--------------+
               |
               | Reads shared pipeline status
               v

     Queue depth | Event bits | Heartbeats | Last ride command


===============================================================================
IPC PRIMITIVES USED
===============================================================================

1. Queue:
   producer_task -> data_q -> consumer_task

2. Event group:
   producer_task + consumer_task -> coordinator_task

3. Direct task notification:
   coordinator_task -> responder_task
   button_isr -> responder_task
===============================================================================
## Engineering analysis prompts (graded, see above for full question)

1. Why pin the web server to Core 0 vs Core 1? (The scaffold puts the monitor on Core 0 - defend or challenge that.)
The web server is placed on Core 0 so Wi-Fi, HTTP requests, and webpage 
updates do not delay the Hulk ride-control tasks on Core 1. Putting it 
on Core 1 could increase jitter, button-response time, and state-machine 
latency. The tradeoff is that Core 0 reads shared monitoring variables, 
but this is less harmful than letting networking interfere with real-time control.
2. Queue depth  & pressure - why did you select the size you did?
The producer creates one command every 500 ms: R= 1/0.5 = 2 commands/second
An eight-item queue can hold: 8/2 = 4 seconds of commands

This gives the consumer four seconds to recover from a delay. The 
output shows q_depth=0, meaning the state-machine task is currently 
processing commands fast enough. If the queue becomes full, the 
producer waits briefly and then drops the newest noncritical command 
instead of blocking forever.
3. Explain the pros/cons to Event group vs N semaphores.
An event group is better when one task must wait for several 
Boolean conditions, such as both DATA_PRODUCED and DATA_PROCESSED. 
It uses one object and can wait for any or all selected bits.

Multiple semaphores are better when events must be counted or 
consumed separately. Their disadvantage is that they require 
more objects and make waiting for several conditions more 
complicated. Event bits do not count repeated events; setting 
the same bit multiple times still stores only one set state.
4. Direct notification vs binary semaphore — with measured numbers.
The direct task notification produced a minimum latency of 12 µs, 
an average of 16 µs, and a maximum of 32 µs over 68 samples. The 
binary semaphore produced a minimum latency of 13 µs, an average 
of 17 µs, and a maximum of 18 µs over 49 samples. The direct 
notification was 1 µs, or approximately 5.9%, faster on average. 
This supports using a direct notification for the one-to-one button 
ISR-to-responder path because it requires less kernel overhead and 
no separate semaphore object. However, the binary semaphore had a 
lower maximum latency in this particular run, showing that individual 
measurements can vary because of scheduling and background activity.
## Viewing the web monitor (`USE_WEBSERVER=1`, if you implement it on real hw)

The scaffold ships `webmonitor_task` as a stub. After you port App 1's HTTP code in and flip `USE_WEBSERVER` to `1`, the workflow is identical to App 1/2:

- Wi-Fi connects &rarr; serial monitor prints `Got IP: 10.13.37.x`
- A network indicator appears in Wokwi's simulator panel once port 80 is up
- Click "Open in new tab" to view the page

For App 5 specifically, the page should show live **queue depth** (`uxQueueMessagesWaiting(data_q)`), **event-group bit state** (`xEventGroupGetBits(evt_group)`), and the per-task heartbeats. The auto-refresh interval is your choice &mdash; 1 Hz is reasonable; faster than that and you'll see your own HTTP handler showing up in the latency measurements.

Until the web monitor is implemented, run on `USE_WEBSERVER=0`: the serial monitor prints `[monitor] q_depth=… evt=… hb: prod=… cons=… coord=… resp=…` once a second, and every `[responder] notified (count=N)` line confirms the IPC pipeline is moving.

## Honor code

You're now reusing infrastructure from Apps 1&ndash;3. That's NOT cheating &mdash; that's engineering. Cite where each block came from in the README.
ChatGPT used: https://chatgpt.com/c/6a67b4fe-b4bc-83ea-8e70-762017b64bfa
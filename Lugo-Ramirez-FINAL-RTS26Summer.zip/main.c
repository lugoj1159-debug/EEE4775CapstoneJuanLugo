/*
 * App 5 / Final Capstone measurement build
 * Hulk Launch & Safety Control System
 *
 * Paste this entire file into main/main.c.
 * This version always uses the SERIAL monitor so data prints immediately.
 */

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <limits.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/event_groups.h"
#include "freertos/semphr.h"

#include "driver/gpio.h"
#include "esp_timer.h"
#include "esp_err.h"
#include "esp_attr.h"

/* ============================================================
 * TEST SETTINGS — change only these three values
 * ============================================================ */

/* 0 = normal pipeline/WCET test, 1 = button latency test */
#define LATENCY_TEST_MODE 0

/* Used only when LATENCY_TEST_MODE = 1
 * 1 = direct task notification, 0 = binary semaphore
 */
#define USE_DIRECT_NOTIFICATION 1

/* 0 = normal track sensor, 1 = inject track-clear failure */
#define INJECT_TRACK_FAULT 0

/* ============================================================ */

#define BUTTON_GPIO        GPIO_NUM_18
#define QUEUE_DEPTH        8
#define PRODUCER_PERIOD_MS 500
#define BUTTON_DEBOUNCE_US 200000U

#define EV_BIT_DATA_PRODUCED  (1U << 0)
#define EV_BIT_DATA_PROCESSED (1U << 1)

static const EventBits_t PIPELINE_BITS =
    EV_BIT_DATA_PRODUCED | EV_BIT_DATA_PROCESSED;

typedef enum {
    CMD_LOCK_RESTRAINTS = 0,
    CMD_TRACK_CLEAR,
    CMD_DISPATCH,
    CMD_RESET
} RideCommand_t;

typedef enum {
    RIDE_LOADING = 0,
    RIDE_RESTRAINTS_LOCKED,
    RIDE_READY,
    RIDE_RUNNING
} RideState_t;

typedef struct {
    uint32_t timestamp_ms;
    uint32_t sequence;
    RideCommand_t command;
} RideItem_t;

/* IPC objects */
static QueueHandle_t data_q;
static EventGroupHandle_t evt_group;
static SemaphoreHandle_t button_sem;
static TaskHandle_t responder_handle;

/* Monitor state */
static volatile uint32_t hb_prod;
static volatile uint32_t hb_cons;
static volatile uint32_t hb_coord;
static volatile uint32_t hb_resp;

static volatile uint32_t dropped_items;
static volatile RideState_t ride_state = RIDE_LOADING;
static volatile RideCommand_t last_command = CMD_RESET;

/* WCET maxima in microseconds */
static volatile uint32_t wcet_prod_us;
static volatile uint32_t wcet_cons_us;
static volatile uint32_t wcet_coord_us;
static volatile uint32_t wcet_resp_us;
static volatile uint32_t wcet_monitor_us;

/* Button latency data */
static volatile uint32_t last_edge_us;
static volatile uint32_t button_isr_time_us;
static portMUX_TYPE latency_mux = portMUX_INITIALIZER_UNLOCKED;

static uint32_t latency_samples;
static uint32_t latency_last_us;
static uint32_t latency_min_us = UINT32_MAX;
static uint32_t latency_max_us;
static uint64_t latency_total_us;

static void update_wcet(volatile uint32_t *maximum, uint32_t measured)
{
    if (measured > *maximum) {
        *maximum = measured;
    }
}

static const char *command_name(RideCommand_t command)
{
    switch (command) {
        case CMD_LOCK_RESTRAINTS: return "LOCK_RESTRAINTS";
        case CMD_TRACK_CLEAR:     return "TRACK_CLEAR";
        case CMD_DISPATCH:        return "DISPATCH";
        case CMD_RESET:           return "RESET";
        default:                  return "UNKNOWN";
    }
}

static const char *state_name(RideState_t state)
{
    switch (state) {
        case RIDE_LOADING:           return "LOADING";
        case RIDE_RESTRAINTS_LOCKED: return "RESTRAINTS_LOCKED";
        case RIDE_READY:             return "READY_TO_LAUNCH";
        case RIDE_RUNNING:           return "RIDE_RUNNING";
        default:                     return "UNKNOWN";
    }
}

/* ---------- Producer task: themed operator input ---------- */
static void producer_task(void *arg)
{
    TickType_t last_wake = xTaskGetTickCount();
    uint32_t sequence = 0;
    int command_number = 0;

    for (;;) {
        int64_t start_us = esp_timer_get_time();

        RideItem_t item = {
            .timestamp_ms = (uint32_t)(esp_timer_get_time() / 1000),
            .sequence = ++sequence,
            .command = (RideCommand_t)command_number
        };

        if (xQueueSend(data_q, &item, pdMS_TO_TICKS(10)) == pdPASS) {
            last_command = item.command;
            xEventGroupSetBits(evt_group, EV_BIT_DATA_PRODUCED);
        } else {
            dropped_items++;
            printf("[QUEUE FULL] dropped command=%s\n",
                   command_name(item.command));
        }

        command_number++;
        if (command_number > CMD_RESET) {
            command_number = CMD_LOCK_RESTRAINTS;
        }

        hb_prod++;
        update_wcet(&wcet_prod_us,
                    (uint32_t)(esp_timer_get_time() - start_us));

        vTaskDelayUntil(&last_wake, pdMS_TO_TICKS(PRODUCER_PERIOD_MS));
    }
}

/* ---------- Consumer task: Hulk ride state machine ---------- */
static void consumer_task(void *arg)
{
    RideItem_t item;

    for (;;) {
        if (xQueueReceive(data_q, &item, portMAX_DELAY) != pdPASS) {
            continue;
        }

        int64_t start_us = esp_timer_get_time();

        switch (item.command) {
            case CMD_LOCK_RESTRAINTS:
                ride_state = RIDE_RESTRAINTS_LOCKED;
                printf("[STATE] restraints locked\n");
                break;

            case CMD_TRACK_CLEAR:
#if INJECT_TRACK_FAULT
                printf("[FAULT] track-clear sensor failed\n");
                printf("[SAFETY] system remains not ready\n");
#else
                if (ride_state == RIDE_RESTRAINTS_LOCKED) {
                    ride_state = RIDE_READY;
                    printf("[STATE] track clear - ready to launch\n");
                }
#endif
                break;

            case CMD_DISPATCH:
                if (ride_state == RIDE_READY) {
                    ride_state = RIDE_RUNNING;
                    printf("[STATE] Hulk coaster dispatched\n");
                } else {
                    printf("[SAFETY] dispatch blocked - checks incomplete\n");
                }
                break;

            case CMD_RESET:
                ride_state = RIDE_LOADING;
                printf("[STATE] reset for next train\n");
                break;

            default:
                break;
        }

        xEventGroupSetBits(evt_group, EV_BIT_DATA_PROCESSED);
        hb_cons++;

        update_wcet(&wcet_cons_us,
                    (uint32_t)(esp_timer_get_time() - start_us));
    }
}

/* ---------- Coordinator task: event-group rendezvous ---------- */
static void coordinator_task(void *arg)
{
    for (;;) {
        EventBits_t bits = xEventGroupWaitBits(
            evt_group,
            PIPELINE_BITS,
            pdTRUE,          /* clear both bits after rendezvous */
            pdTRUE,          /* wait for all bits */
            portMAX_DELAY
        );

        if ((bits & PIPELINE_BITS) == PIPELINE_BITS) {
            int64_t start_us = esp_timer_get_time();

#if !LATENCY_TEST_MODE
            /* Normal App 5 pipeline: coordinator wakes display task. */
            xTaskNotifyGive(responder_handle);
#endif

            hb_coord++;
            update_wcet(&wcet_coord_us,
                        (uint32_t)(esp_timer_get_time() - start_us));
        }
    }
}

/* ---------- Responder/operator-display task ---------- */
static void responder_task(void *arg)
{
    for (;;) {
#if LATENCY_TEST_MODE
    #if USE_DIRECT_NOTIFICATION
        uint32_t received = ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        if (received == 0) {
            continue;
        }
    #else
        if (xSemaphoreTake(button_sem, portMAX_DELAY) != pdTRUE) {
            continue;
        }
    #endif
#else
        uint32_t received = ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        if (received == 0) {
            continue;
        }
#endif

        int64_t start_us = esp_timer_get_time();

#if LATENCY_TEST_MODE
        uint32_t wake_us = (uint32_t)esp_timer_get_time();
        uint32_t latency_us = wake_us - button_isr_time_us;

        portENTER_CRITICAL(&latency_mux);

        latency_samples++;
        latency_last_us = latency_us;
        latency_total_us += latency_us;

        if (latency_us < latency_min_us) {
            latency_min_us = latency_us;
        }

        if (latency_us > latency_max_us) {
            latency_max_us = latency_us;
        }

        uint32_t average_us =
            (uint32_t)(latency_total_us / latency_samples);

        portEXIT_CRITICAL(&latency_mux);

    #if USE_DIRECT_NOTIFICATION
        printf("[LATENCY] DIRECT sample=%lu current=%lu us "
               "min=%lu us avg=%lu us max=%lu us\n",
               (unsigned long)latency_samples,
               (unsigned long)latency_us,
               (unsigned long)latency_min_us,
               (unsigned long)average_us,
               (unsigned long)latency_max_us);
    #else
        printf("[LATENCY] SEMAPHORE sample=%lu current=%lu us "
               "min=%lu us avg=%lu us max=%lu us\n",
               (unsigned long)latency_samples,
               (unsigned long)latency_us,
               (unsigned long)latency_min_us,
               (unsigned long)average_us,
               (unsigned long)latency_max_us);
    #endif
#else
        printf("[DISPLAY] state=%s command=%s\n",
               state_name(ride_state),
               command_name(last_command));
#endif

        hb_resp++;
        update_wcet(&wcet_resp_us,
                    (uint32_t)(esp_timer_get_time() - start_us));
        fflush(stdout);
    }
}

/* ---------- Button ISR ---------- */
static void IRAM_ATTR button_isr(void *arg)
{
    uint32_t now_us = (uint32_t)esp_timer_get_time();

    if ((now_us - last_edge_us) < BUTTON_DEBOUNCE_US) {
        return;
    }

    last_edge_us = now_us;
    button_isr_time_us = now_us;

    BaseType_t higher_priority_task_woken = pdFALSE;

#if LATENCY_TEST_MODE
    #if USE_DIRECT_NOTIFICATION
    vTaskNotifyGiveFromISR(
        responder_handle,
        &higher_priority_task_woken
    );
    #else
    xSemaphoreGiveFromISR(
        button_sem,
        &higher_priority_task_woken
    );
    #endif
#else
    /* Normal App 5 button path uses a direct task notification. */
    vTaskNotifyGiveFromISR(
        responder_handle,
        &higher_priority_task_woken
    );
#endif

    portYIELD_FROM_ISR(higher_priority_task_woken);
}

/* ---------- Core-0 serial monitor ---------- */
static void serial_monitor_task(void *arg)
{
    for (;;) {
        int64_t start_us = esp_timer_get_time();

        UBaseType_t depth = uxQueueMessagesWaiting(data_q);
        EventBits_t bits = xEventGroupGetBits(evt_group);

        uint32_t samples;
        uint32_t last_us;
        uint32_t minimum_us;
        uint32_t maximum_us;
        uint32_t average_us;

        portENTER_CRITICAL(&latency_mux);

        samples = latency_samples;
        last_us = latency_last_us;
        minimum_us = (latency_samples == 0) ? 0 : latency_min_us;
        maximum_us = latency_max_us;
        average_us = (latency_samples == 0)
                         ? 0
                         : (uint32_t)(latency_total_us / latency_samples);

        portEXIT_CRITICAL(&latency_mux);

        double core1_utilization =
            ((double)wcet_prod_us  / 500000.0) +
            ((double)wcet_cons_us  / 500000.0) +
            ((double)wcet_coord_us / 500000.0) +
            ((double)wcet_resp_us  / 200000.0);

        printf("\n============================================================\n");
        printf("[MONITOR] q_depth=%u/%u evt=0x%02x state=%s last=%s drops=%lu\n",
               (unsigned)depth,
               QUEUE_DEPTH,
               (unsigned)bits,
               state_name(ride_state),
               command_name(last_command),
               (unsigned long)dropped_items);

        printf("[HEARTBEATS] prod=%lu cons=%lu coord=%lu resp=%lu\n",
               (unsigned long)hb_prod,
               (unsigned long)hb_cons,
               (unsigned long)hb_coord,
               (unsigned long)hb_resp);

        printf("[WCET us] producer=%lu state=%lu coordinator=%lu "
               "display=%lu monitor=%lu\n",
               (unsigned long)wcet_prod_us,
               (unsigned long)wcet_cons_us,
               (unsigned long)wcet_coord_us,
               (unsigned long)wcet_resp_us,
               (unsigned long)wcet_monitor_us);

        printf("[SCHED] Core1_U=%.6f RM_bound=0.756828 EDF_limit=1.000000\n",
               core1_utilization);

#if LATENCY_TEST_MODE
    #if USE_DIRECT_NOTIFICATION
        printf("[LATENCY SUMMARY] method=DIRECT_NOTIFICATION ");
    #else
        printf("[LATENCY SUMMARY] method=BINARY_SEMAPHORE ");
    #endif
        printf("samples=%lu last=%lu min=%lu avg=%lu max=%lu us\n",
               (unsigned long)samples,
               (unsigned long)last_us,
               (unsigned long)minimum_us,
               (unsigned long)average_us,
               (unsigned long)maximum_us);
#else
        printf("[MODE] normal pipeline / WCET collection\n");
#endif

#if INJECT_TRACK_FAULT
        printf("[FAULT INJECTION] TRACK SENSOR FAILURE ENABLED\n");
#else
        printf("[FAULT INJECTION] disabled\n");
#endif

        printf("============================================================\n");
        fflush(stdout);

        update_wcet(&wcet_monitor_us,
                    (uint32_t)(esp_timer_get_time() - start_us));

        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

void app_main(void)
{
    printf("\n==== Hulk Capstone app_main started ====\n");
    printf("LATENCY_TEST_MODE=%d USE_DIRECT_NOTIFICATION=%d "
           "INJECT_TRACK_FAULT=%d\n",
           LATENCY_TEST_MODE,
           USE_DIRECT_NOTIFICATION,
           INJECT_TRACK_FAULT);
    fflush(stdout);

    data_q = xQueueCreate(QUEUE_DEPTH, sizeof(RideItem_t));
    evt_group = xEventGroupCreate();
    button_sem = xSemaphoreCreateBinary();

    configASSERT(data_q != NULL);
    configASSERT(evt_group != NULL);
    configASSERT(button_sem != NULL);

    /* Create responder first so its task handle exists before the ISR runs. */
    configASSERT(xTaskCreatePinnedToCore(
        responder_task,
        "operator_display",
        4096,
        NULL,
        12,
        &responder_handle,
        APP_CPU_NUM
    ) == pdPASS);

    configASSERT(xTaskCreatePinnedToCore(
        coordinator_task,
        "ride_coord",
        4096,
        NULL,
        9,
        NULL,
        APP_CPU_NUM
    ) == pdPASS);

    configASSERT(xTaskCreatePinnedToCore(
        consumer_task,
        "ride_state",
        4096,
        NULL,
        8,
        NULL,
        APP_CPU_NUM
    ) == pdPASS);

    configASSERT(xTaskCreatePinnedToCore(
        producer_task,
        "button_input",
        4096,
        NULL,
        8,
        NULL,
        APP_CPU_NUM
    ) == pdPASS);

    configASSERT(xTaskCreatePinnedToCore(
        serial_monitor_task,
        "monitor",
        4096,
        NULL,
        4,
        NULL,
        PRO_CPU_NUM
    ) == pdPASS);

    gpio_config_t button_config = {
        .pin_bit_mask = 1ULL << BUTTON_GPIO,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_NEGEDGE
    };

    ESP_ERROR_CHECK(gpio_config(&button_config));

    esp_err_t isr_result = gpio_install_isr_service(0);
    if (isr_result != ESP_OK && isr_result != ESP_ERR_INVALID_STATE) {
        ESP_ERROR_CHECK(isr_result);
    }

    ESP_ERROR_CHECK(
        gpio_isr_handler_add(BUTTON_GPIO, button_isr, NULL)
    );

    printf("Startup complete. The monitor will print once per second.\n");
    printf("GPIO 18 button is ready.\n");
    fflush(stdout);
}